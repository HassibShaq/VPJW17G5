#include<newfunction.h>
#include<constants.h>
using namespace cv;

double calculateangle(std::vector<Point2f> marker, int& quadrant)
{
    //Variables
    double angle = 0.0;                //Angle
    double tempangle = 0.0;            //Temporary Angle for loop
    std::vector<double> delta(4,0.0);  //diff. x. y
    int a = 3;                          //default Value is 3


    //Swap Elements 0 and 1 from Corner Vektor to compare Corner 2 and 3            Swap ist für den Vergleich der Ecken notwendig
    //std::swap(marker[0],marker[1]);


    //Calculate Angle based on the Quadrant of Angles
    for(int i =0;i<4;i++)
    {



        //for Angle between Corner 0->1 and 2->3
        if(i!=0)
        {
            a = -1;
        }


        //Default Quadrant is I
        quadrant = 1;


        //Calculate Angle
        delta[i] = -marker[i+a].x + marker[i].x;
        delta[i+a] = -marker[i].y + marker[i+a].y;
        tempangle = atan(delta[i+a]/delta[i])*180/3.14159265359;


        //Calculate and add the offset for Quadrant II-IV.
        //Quadrant II
        if(marker[i].x < marker[i+a].x && marker[i].y < marker[i+a].y)
        {
            tempangle = tempangle+180;
            quadrant = 2;

        }

        //Quadrant III
        if(marker[i+a].x > marker[i].x && marker[i+a].y < marker[i].y)
        {

            tempangle = tempangle+180;
            quadrant = 3;

        }

        //Quadrant IV
        if(marker[i].x > marker[i+a].x && marker[i].y > marker[i+a].y)
        {
            tempangle = tempangle+360;
            quadrant = 4;
        }

        if(i==0)
        {
            qDebug() << "Ecke:0";
            qDebug() << floor(tempangle);
            //MainWindow::ui->InputM3->setText(QString::number(floor(tempangle)));
        }

        if(i==1)
        {
            qDebug() << "Ecke:1";
            tempangle = tempangle+90;
            qDebug() << floor(tempangle);
            //MainWindow::ui->InputM0->setText(QString::number(floor(tempangle)));
        }

        if(i==2)
        {
            qDebug() << "Ecke:2";
            tempangle = tempangle+180;
            qDebug() << floor(tempangle);
            //MainWindow::ui->InputM1->setText(QString::number(floor(tempangle)));
        }

        if(i==3)
        {
            qDebug() << "Ecke:3";
            tempangle = tempangle+270;
            qDebug() << floor(tempangle);
            //MainWindow::ui->InputM2->setText(QString::number(floor(tempangle)));
        }


        //If the Angle is overflowed
        if(tempangle>360)
            tempangle=tempangle-360;


        //Amount of Angle
        angle = angle+tempangle;

    }
    //Average
    angle = angle/4;                                                        //ACHTUNG! FESTER WERT ERSETZEN

    return angle;
}

double calculateanglebetweenmarker(std::vector<Point2f> marker1, std::vector<Point2f> marker2)
{
    //Variablen deklaration
    double angle = 0.0;                //Angle
    std::vector<double> delta(2,0.0);  //diff. x. y


    //Calculate Angle between the first Corner of booth Markers
    delta[0] = marker1[0].x - marker2[0].x;
    delta[1] = marker2[0].y - marker1[0].y;
    angle = atan(delta[1]/delta[0])*180/3.14159265359;


    //Calculate and add the offset for Quadrant II-IV.
    //Quadrant II
    if(marker1[0].x < marker2[0].x && marker1[0].y < marker2[0].y)
    {
        angle = angle+180;
    }


    //Quadrant III
    if(marker1[0].x < marker2[0].x && marker1[0].y > marker2[0].y)
    {
        angle = angle+180;
    }


    //Quadrant IV
    if(marker1[0].x > marker2[0].x && marker1[0].y > marker2[0].y)
    {
        angle = angle+360;
    }


    return angle;

}

Point2f calculatemiddlepoint(std::vector<Point2f> marker1, std::vector<Point2f> marker2, double angle)
{
    //Kann auch als Punkt zurück gegeben werden!
    std::vector<int> x(4,0.0);                     //Vector for middle x-values
    Point2f temp;                     //Temporary Vector
    Point2f temp1;                     //Temporary Vector
    Point2f temp2;                     //Temporary Vector
    Point2f offset;                     //Temporary Vector
    Point2f middlepoint;              //Vector with calculated Middlepoint
    int n = 0;                                     //Divisor for Middlevalue

    //Calculate Middlevalue for Marker 1
    if(marker1.size()>0)
    {
        for(int i = 0;i<4;i++)
        {
            temp1.x=temp1.x+marker1[i].x;
            temp1.y=temp1.y+marker1[i].y;
        }
        n++;

        middlepoint.x = middlepoint.x+temp1.x/4;
        middlepoint.y = middlepoint.y+temp1.y/4;

        //temp.x = 0;
        //temp.y = 0;
    }




    //Calculate Middlevalue for Marker 2
    if(marker2.size()>0)
    {
        for(int i = 0;i<4;i++)
        {
            temp2.x=temp2.x+marker2[i].x;
            temp2.y=temp2.y+marker2[i].y;
        }
        n++;

        middlepoint.x = middlepoint.x+temp2.x/4;
        middlepoint.y = middlepoint.y+temp2.y/4;

        //temp.x = 0;
        //temp.y = 0;
    }




    //Calculate Middlevalue between Marker one and two.
    if(marker1.size()>0 && marker2.size()>0)
    {
        middlepoint.x = middlepoint.x/2;
        middlepoint.y = middlepoint.y/2;


        temp.x=temp.x+marker1[0].x;
        temp.y=temp.y+marker1[0].y;

        temp.x=temp.x+marker1[1].x;
        temp.y=temp.y+marker1[1].y;

        temp.y=temp.y+marker2[2].x;
        temp.y=temp.y+marker2[2].y;

        temp.y=temp.y+marker2[3].x;
        temp.y=temp.y+marker2[3].y;

        n++;

        middlepoint.x = (temp.x/4+middlepoint.x)/2;
        middlepoint.y = (temp.y/4+middlepoint.y)/2;

        //Berechne den Offset
        offset.x = (temp1.x/4-temp2.x/4)/2;
        offset.y = (temp1.y/4-temp2.y/4)/2;

        qDebug() << "X:";
        qDebug() << offset.x;
        qDebug() << "Y:";
        qDebug() << offset.y;

    }
    else
    //If only one Marker detected add a Offset
    {
        //Add Offset
        qDebug() << "NEEEEEEEEEEEEEEEEE:";
        middlepoint.x = middlepoint.x+cos(angle*3.14159265359/180)*16.58561;
        middlepoint.y = middlepoint.y+sin(angle*3.14159265359/180)*16.58561;
        qDebug() << middlepoint.x;
        qDebug() << middlepoint.y ;
    }

    return middlepoint;
}

void sortbyfirstvector(std::vector<int> *markerIds, std::vector<std::vector<Point2f> > *markerCorners)
{
    //Make a Copy from booth Vectors
    std::vector<int> tempIds = *markerIds;
    std::vector<int> markerIDS = *markerIds;

    std::vector<std::vector<Point2f>> markerCORNERS = *markerCorners;
    std::vector<std::vector<Point2f>> tempCorners;
    tempCorners.resize(markerCORNERS.size());

    //Sort the first Vector
    std::sort(tempIds.begin(),tempIds.end());

    //Search the Elements
    for(unsigned int i = 0; i < tempIds.size();i++)
    {
        for(unsigned int a = 0; a < tempIds.size();a++)
        {
            //If the Value was sort from Position i to Position a
            if(markerIDS[i] == tempIds[a])
            {
                //swap the Corners also
                tempCorners[a] = markerCORNERS[i];
            }
        }
    }

    //Write the new sorted Vectors
    *markerCorners = tempCorners;
    *markerIds = tempIds;
    return;
}
