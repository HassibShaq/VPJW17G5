#ifndef MYUDP_H
#define MYUDP_H

#include <QObject>
#include <QUdpSocket>
#include <QTime>
#include <opencv2/opencv.hpp>

class MyUDP : public QObject
{
    Q_OBJECT
public:
    explicit MyUDP(QObject *parent = 0);
    void sendUdpData(QList<cv::Point3f> robotLocations, int numberOfRobots, QTime timeStamp);
    void setSendIP( QString SendToIp, int SendToPort);

signals:

public slots:
    void readReady();

private:
    QUdpSocket socket;

    QString sendIP;
    int sendPort;

};

#endif // MYUDP_H
