/****************************************************************************
 * This is the RobotDetection main programm. It is part of the camera
 * calibration and robot detection system created by  "Gewerk 5"  during the
 * cooperative project of automation technologies in 2013/2014 at the Hamburg
 * University of Applied Sciences.
 *
 * Filename: robotdetectionmainwindow.cpp
 * Author:   Markus Baden
 * Created:  2013-12-24
 * Changed:  2014-04-17
 ***************************************************************************/

#include "robotdetectionmainwindow.h"
#include "ui_robotdetectionmainwindow.h"

using namespace cv;



RobotDetectionMainWindow::RobotDetectionMainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::RobotDetectionMainWindow),
    udpClient(this),
    threadPool(this)
{
    ui->setupUi(this);
    // read settings from ini file
    QSettings settings("settings.ini", QSettings::IniFormat);
    settings.beginGroup("RobotDetectionSettings");
    sendToIp = settings.value("SendToIP", "192.168.0.12").toString();
    sendToPort = settings.value("SendToPort", 25000).toInt();
    timerMilSecs = settings.value("TimerMilSecs", 20).toInt();
    ui->sliderBigToNone->setValue  ( settings.value("MaxRadius", 40).toInt() );
    ui->sliderSmallToNone->setValue( settings.value("MinRadius", 10).toInt() );
    ui->sliderDuplicate->setValue  ( settings.value("CloseDist", 40).toInt() );
    ui->sliderThreshold->setValue  ( settings.value("Threshold", 75).toInt() );
    ui->sliderBigToMiddle->setValue( settings.value("MaxToMidRadius", 30).toInt());
    ui->sliderMiddleToSmall->setValue( settings.value("MidToMinRadius", 20).toInt());
    ui->sliderCodingAngle->setValue( settings.value("CodingAngle", 30).toInt());

    settings.endGroup();

    // create UDP-Client and open socket
    udpClient.setSendIP(sendToIp, sendToPort);

    mainloopIsActive = false;

    // init timers for mainloop and frames-per-second counting
    connect(&timer, SIGNAL(timeout()), this, SLOT(operate()));
    connect(&timerFPS, SIGNAL(timeout()), this, SLOT(fpsCounter()));
    fpsCount = 0;

    // read camera calibration data and perspective transform matrices from xml
    readXmlCalibrationFile();

    // read test image
    //    QString fileName = QFileDialog::getOpenFileName(this,"Bilddatei laden","","Bilder (*.jpg)");
    //    testImage = cv::imread(fileName.toStdString());

    // init list of robotLocations
    robotLocations.clear();

    for (int i = 0; i < MAX_NR_OF_ROBOTS; i++)
    {
        robotLocations.append(Point3f(0.0, 0.0, 0.0));
    }

    // open threadpool for image analysis
    threadPool.setMaxThreadCount(NR_OF_CAMS);
    for (int i = 0; i < NR_OF_CAMS; i++)
    {
        tasks[i] = new ImgTask();
        tasks[i]->setAutoDelete(false);
        tasks[i]->setCameraMatrix(cameraMatrix.at(i));
        tasks[i]->setDistCoeffs(distCoeffs.at(i));
        tasks[i]->setPerspTransfMatrix(perspTransfMatrix.at(i));
    }

    ui->labelVersion->setText("Version: " + QString(__DATE__) + " " + QString(__TIME__));

    setMaximumSize(size());
}

RobotDetectionMainWindow::~RobotDetectionMainWindow()
{
    // write settings to ini file
    QSettings settings("settings.ini", QSettings::IniFormat);
    settings.beginGroup("RobotDetectionSettings");
    settings.setValue("SendToIP", sendToIp);
    settings.setValue("SendToPort", sendToPort);
    settings.setValue("TimerMilSecs", timerMilSecs);
    settings.setValue("MaxRadius", ui->sliderBigToNone->value());
    settings.setValue("MinRadius", ui->sliderSmallToNone->value());
    settings.setValue("CloseDist", ui->sliderDuplicate->value());
    settings.setValue("Threshold", ui->sliderThreshold->value());
    settings.setValue("MaxToMidRadius", ui->sliderBigToMiddle->value());
    settings.setValue("MidToMinRadius", ui->sliderMiddleToSmall->value());
    settings.setValue("CodingAngle", ui->sliderCodingAngle->value());

    settings.endGroup();

    // clean up
    for (int i = 0; i < NR_OF_CAMS; i++)
    {
        delete tasks[i];
    }
    delete ui;
}

void RobotDetectionMainWindow::on_pushButtonStartStop_clicked()
{
    if(mainloopIsActive)
    {
        timer.stop();
        timerFPS.stop();
        for (int i = 0; i < NR_OF_CAMS; i++)
        {
            videoCapture[i].release();
        }
        ui->statusBar->showMessage("Releasing cameras...", 2000);
        ui->pushButtonStartStop->setText("Start Detection");
        mainloopIsActive = false;
    }
    else
    {
        for (int i = 0; i < NR_OF_CAMS; i++)
        {
            videoCapture[i].open(i);
            videoCapture[i].set(CV_CAP_PROP_FRAME_WIDTH, CAMERA_IMG_WIDTH);
            videoCapture[i].set(CV_CAP_PROP_FRAME_HEIGHT, CAMERA_IMG_HEIGTH);
            videoCapture[i].set(CV_CAP_PROP_BRIGHTNESS, brightnessValue[i]);
            videoCapture[i].set(CV_CAP_PROP_CONTRAST, contrastValue[i]);
            videoCapture[i].set(CV_CAP_PROP_EXPOSURE, exposureValue[i]);
        }
        ui->statusBar->showMessage("Connecting to cameras...", 3000);
        // give cameras some time to get connected,
        // otherwise program might crash (depends on camera driver)
        Sleep(3000);
        timer.start(timerMilSecs);
        timerFPS.start(100);
        ui->pushButtonStartStop->setText("Stop Detection");
        mainloopIsActive = true;
    }
}



    /*
    ui->labelThreshold->setNum(ui->sliderThreshold->value());
    ui->labelBigNoneValue->setNum(ui->sliderBigToNone->value());
    ui->labelSmallNoneValue->setNum(ui->sliderSmallToNone->value());
    ui->labelDuplicateValue->setNum(ui->sliderDuplicate->value());
    ui->labelMaxMiddleValue->setNum(ui->sliderBigToMiddle->value());
    ui->labelMiddleMinValue->setNum(ui->sliderMiddleToSmall->value());
    ui->labelCodingAngleValue->setNum(ui->sliderCodingAngle->value());

    */



void RobotDetectionMainWindow::operate()
{
    if(!workerMutex.tryLock())
    {
        return;
    }

    // GRAB TIMESTAMP
    timeStamp = QTime::currentTime(); // read system time
    QString stime = timeStamp.toString(Qt::LocalDate);  // convert time to string
    //    qDebug() << stime;

    fpsCount++;

    // READ IMAGES FROM CAMERAS
    // grab frames with smallest time difference possible
    // "grab()" + "retrieve()" is faster than the combined function "read()"

    for (int i = 0; i < NR_OF_CAMS; i++)
    {
        if (videoCapture[i].isOpened())
        {
            videoCapture[i].grab();
        }
    }


    for (int i = 0; i < NR_OF_CAMS; i++)
    {
        if (videoCapture[i].isOpened())
        {
            videoCapture[i].retrieve(cameraImages[i], 0);   // get frames from camera
            //videoCapture[i] >> cameraImages[i];
        }
        else     // no camera connected, use black image
        {
            Mat blackImage(CAMERA_IMG_HEIGTH, CAMERA_IMG_WIDTH, CV_8UC3);
            blackImage.setTo(COLOR_BLACK);
            cameraImages[i] = blackImage;
            qDebug() << "BlackImage!";
        }
        // start seperate tasks
        tasks[i]->setImage( cameraImages[i] );
        tasks[i]->setThresh( ui->sliderThreshold->value() );
        tasks[i]->setDebugMode( ui->checkBoxLiveView->isChecked() );
        threadPool.start( tasks[i] );
    }
    threadPool.waitForDone();

    // Fetch data (circles) from finished tasks
    QList<Point3f> circles;
    for (int i = 0; i < NR_OF_CAMS; i++)
    {
        circles.append(tasks[i]->getCircles());
    }

    // Display either camera images or white background
    Mat guiImage(GUI_HEIGTH, GUI_WIDTH, CV_8UC3);
    if (ui->checkBoxLiveView->isChecked())   // show real frames
    {
        guiImage.setTo(COLOR_BLACK);
        for (int i = 0; i < NR_OF_CAMS; i++)
        {
            addWeighted(guiImage, 1, tasks[i]->getWarpedImage(), 1, 0, guiImage, -1);
        }
    }
    else     // show white background with grid
    {
        guiImage.setTo(COLOR_WHITE);
        for (unsigned int i = 0; i < 40; i++)
        {
            if (i % 5 == 0)
            {
                line(guiImage, Point(i * 200 / GUI_SCALING, 0), Point(i * 200 / GUI_SCALING, guiImage.rows), COLOR_DARK_GREY,  1, 8, 0);
            }
            else
            {
                line(guiImage, Point(i * 200 / GUI_SCALING, 0), Point(i * 200 / GUI_SCALING, guiImage.rows), COLOR_LIGHT_GREY, 1, 8, 0);
            }
        }
        for (unsigned int i = 0; i < 20; i++)
        {
            if (i % 5 == 0)
            {
                line(guiImage, Point(0, i * 200 / GUI_SCALING), Point(guiImage.cols, i * 200 / GUI_SCALING), COLOR_DARK_GREY,  1, 8, 0);
            }
            else
            {
                line(guiImage, Point(0, i * 200 / GUI_SCALING), Point(guiImage.cols, i * 200 / GUI_SCALING), COLOR_LIGHT_GREY, 1, 8, 0);
            }
        }
    }

    // init locations with zeros
    for (int i = 0; i < MAX_NR_OF_ROBOTS; i++)
    {
        robotLocations[i] = Point3f(0, 0, 0);
    }

    // find robot locations
    if (ui->checkBoxNewAlgo->isChecked())
    {
        locateRobotsFromCirclesAlgo2(guiImage, circles);

    }
    else
    {
        //locateRobotsFromCirclesAlgo1(guiImage, circles);
        locateRobotsFromCirclesAlgo3(circles);

    }

    // sendUDPdata...
    udpClient.sendUdpData(robotLocations, MAX_NR_OF_ROBOTS, timeStamp);

    // write robotLocations to tablewidget
    writeRobotLocationsToTable();

    // invert y-axis
    flip(guiImage, guiImage, 0);

    // show error message in image if camera is missing
    for (int i = 0; i < NR_OF_CAMS; i++ )
    {
        if( ! videoCapture[i].isOpened())
        {
            QString str = "Camera not connected. ID: ";
            str.append(QString::number(i));
            std::string str2 = str.toStdString();
            double x = 0, y = 0;
            if ( i % 2 == 0)
            {
                y = GUI_HEIGTH / 4 - 20;
            }
            else
            {
                y = GUI_HEIGTH * 3 / 4 + 20;
            }
            if ( (i == 0) || (i == 5) )
            {
                x = 60;
            }
            else if ( (i == 1) || (i == 2) )
            {
                x = 60 + GUI_WIDTH / 3;
            }
            else if ( (i == 3) || (i == 4) )
            {
                x = 60 + 2 * GUI_WIDTH / 3;
            }
            putText(guiImage, str2, Point2f(x, y), CV_FONT_HERSHEY_PLAIN, 1, COLOR_DARK_GREY, 1, 8, false);
        }
    }

    // Write robot IDs into guiImage
    writeRobotIDsToGui(guiImage);

    // convert colors and show image in GUI
    cvtColor(guiImage, guiImage, CV_BGR2RGB);
    QPixmap pixmap;
    pixmap = QPixmap::fromImage(QImage((unsigned char*) guiImage.data, guiImage.cols, guiImage.rows, QImage::Format_RGB888));
    ui->labelImage->setPixmap(pixmap);

    // clean up
    circles.clear();

    workerMutex.unlock();
}

void RobotDetectionMainWindow::fpsCounter()
{
    QString str = "Frames per second: ";
    str.append(QString::number(fpsCount));
    ui->labelFPS->setText(str);
    fpsCount = 0;
}

void RobotDetectionMainWindow::writeRobotLocationsToTable()
{
    // init tableWidget during first run
    for(int row = 0; row < MAX_NR_OF_ROBOTS; row++)
        for(int col = 0; col < 3; col++)
            if (ui->tableWidget->item(row, col) == 0)
            {
                QTableWidgetItem *itab = new QTableWidgetItem;
                itab->setText("init");
                ui->tableWidget->setItem(row, col, itab);
            }

    // write RobotLocations to tableWidget
    for(int row = 0; row < MAX_NR_OF_ROBOTS; row++)
    {
        ui->tableWidget->item(row, 0)->setText(QString::number(robotLocations.at(row).x, 'f', 1));
        ui->tableWidget->item(row, 1)->setText(QString::number(robotLocations.at(row).y, 'f', 1));
        ui->tableWidget->item(row, 2)->setText(QString::number(robotLocations.at(row).z, 'f', 1));
    }
}

void RobotDetectionMainWindow::writeRobotIDsToGui(cv::Mat guiImage)
{
    Point2f offset = Point2f(ROBOT_RADIUS, - ROBOT_RADIUS);
    for (unsigned int i = 0; i < MAX_NR_OF_ROBOTS; i++)
    {
        Point2f center = Point2f(robotLocations.at(i).x, FIELD_HEIGTH - robotLocations.at(i).y);
        if (center.y != FIELD_HEIGTH)
        {
            putText( guiImage, QString::number(i + 1).toStdString(), scaleToGui(center) + scaleToGui(offset),
                     CV_FONT_HERSHEY_PLAIN, 2, COLOR_RED, 2, CV_AA, false);
        }
    }
}

void RobotDetectionMainWindow::locateRobotsFromCirclesAlgo1(Mat image, QList<cv::Point3f> circles)
{
    if(circles.size() > 0)
    {
        robotLocations[0] = circles[0];
    }

    circles = eliminateCircles(circles, image);

    // sort remaining circles by size in descending order
    qSort(circles.begin(), circles.end(), &radiusIsSmaller);

    for(int i = 0; i < circles.size(); i++ )
    {
        // there can't be more than 4 robots
        if (i >= MAX_NR_OF_ROBOTS)
        {
            break;
        }

        // find circles within range of the largest center circles
        QList<cv::Point3f> circlesInRange;
        for (int j = i + 1; j < circles.size(); j++)
        {
            if( distanceBetweenPoints( circles.at(i), circles.at(j) ) < (ROBOT_RADIUS - 50) )
            {
                // move circle to vector of circles that belong to this very robot
                circlesInRange.append( circles.takeAt(j) );
                j--; // set iterator back one item
            }
        }

        if( circlesInRange.size() > 0 )   // it is a robot
        {
            // current element in vector "circles" is the center circle
            Point2f centerPoint = Point2f( circles.at(i).x, circles.at(i).y);
            double centerRadius = circles.at(i).z;

            // first/largest circle within range of center circle is the orientation circle
            Point2f orientationPoint = Point2f( circlesInRange.at(0).x, circlesInRange.at(0).y);
            double orientationRadius = circlesInRange.at(0).z;


            Point2f directionPoint = (orientationPoint - centerPoint);
            float scale = distanceBetweenPoints(orientationPoint, centerPoint);
            directionPoint.x *= ROBOT_RADIUS / scale;
            directionPoint.y *= ROBOT_RADIUS / scale;
            directionPoint += centerPoint;

            // draw circles and lines for center and orientation circles
            circle(image, scaleToGui(centerPoint), scaleToGui(centerRadius), COLOR_GREEN, 2, CV_AA);
            circle(image, scaleToGui(orientationPoint), scaleToGui(orientationRadius), COLOR_BLUE, 2, CV_AA);
            line  (image, scaleToGui(directionPoint), scaleToGui(centerPoint), COLOR_BLUE, 2, CV_AA);

            // determine robot Position and Angle
            double orientationAngle = horizontalAngle(centerPoint, orientationPoint);
            Point3f robPosition = Point3f(centerPoint.x, centerPoint.y, orientationAngle);

            // erase orientation circle from vector, so all remaining circlesInRange are small identification circles
            circlesInRange.removeFirst();

            // identify robots and write locations
            if (circlesInRange.size() == 2)   // Robot 3 identified
            {
                robotLocations[2] = robPosition;
                Point2f a = Point2f(circlesInRange.at(0).x, circlesInRange.at(0).y);
                Point2f b = Point2f(circlesInRange.at(1).x, circlesInRange.at(1).y);
                circle(image, scaleToGui(a), scaleToGui(circlesInRange.at(0).z), COLOR_RED, 2, CV_AA);
                circle(image, scaleToGui(b), scaleToGui(circlesInRange.at(1).z), COLOR_RED, 2, CV_AA);
                line(image, scaleToGui(a), scaleToGui(centerPoint), COLOR_RED, 2, CV_AA);
                line(image, scaleToGui(b), scaleToGui(centerPoint), COLOR_RED, 2, CV_AA);
            }
            else if (circlesInRange.size() == 1)
            {
                // analyze angles to distinguish Robot 2 and Robot 4
                Point2f identPoint = Point2f(circlesInRange.at(0).x, circlesInRange.at(0).y);
                double identRadius = circlesInRange.at(0).z;

                circle(image, scaleToGui(identPoint), scaleToGui(identRadius), COLOR_RED, 2, CV_AA);
                line  (image, scaleToGui(identPoint), scaleToGui(centerPoint), COLOR_RED, 2, CV_AA);
                double angleDifference = orientationAngle - horizontalAngle(centerPoint, identPoint);
                if( ((angleDifference < 0) && (angleDifference > -180)) || (angleDifference > 180) )   // Robot 2 identified
                {
                    robotLocations[1] = robPosition;
                }
                else     // Robot 4 identified
                {
                    robotLocations[3] = robPosition;
                }
            }
            else if (circlesInRange.size() == 0)     // Robot 1 identified
            {
                robotLocations[0] = robPosition;
            }

            // draw circle around whole robot
            circle(image, scaleToGui(centerPoint), scaleToGui(ROBOT_RADIUS), COLOR_BLUE, 2, CV_AA);
        }
        else
        {
            // not-a-robot
        }

        // clean up
        circlesInRange.clear();
    }
}

void RobotDetectionMainWindow::locateRobotsFromCirclesAlgo2(Mat image, QList<cv::Point3f> circles)
{
    float centerCircleMaxRadius = ui->sliderBigToNone->value();   // center circle diameter is 70mm
    float centerCircleMinRadius = ui->sliderBigToMiddle->value(); // orientation circle diameter is 50mm
    float orientationCircleMaxRadius = ui->sliderBigToMiddle->value();
    float orientationCircleMinRadius = ui->sliderMiddleToSmall->value();         // encoding circle diameter is 30mm
    float encodingCircleMaxRadius = ui->sliderMiddleToSmall->value();
    float encodingCircleMinRadius = ui->sliderSmallToNone->value();
    float distanceCenterOrientation = 100.0;   // distance between center circle and orientation circle is 100mm
    float searchRadius = ROBOT_RADIUS - 50;
    float encodingCircleSector = (float) ui->sliderCodingAngle->value() * (float)(CV_PI / 180.0 / 2.0);

    circles = eliminateCircles(circles, image);

    // sort remaining circles by size in descending order
    qSort(circles.begin(), circles.end(), &radiusIsSmaller);

    int j = 0;
    for(int i = 0; i < circles.size(); i++)
    {
        Point2f centerPoint = Point2f(circles.at(i).x, circles.at(i).y) ;

        if (circles.at(i).z < centerCircleMinRadius)
        {
            break; // No more robot candidates in list
        }

        if (circles.at(i).z < centerCircleMaxRadius)
        {
            // We got a candidate for a robot center
            if (ui->checkBoxLiveView->isChecked())
            {
                circle(image, scaleToGui(centerPoint), scaleToGui(ROBOT_RADIUS), COLOR_LIGHT_GREY, 1, CV_AA);
            }

            // Look for an orientation circle in the right distance
            for (j = i + 1; j < circles.size(); j++)
            {
                if( distanceBetweenPoints( circles.at(i), circles.at(j) ) < (searchRadius)
                        && circles.at(j).z > orientationCircleMinRadius && circles.at(j).z < orientationCircleMaxRadius
                        && distanceBetweenPoints(circles.at(i), circles.at(j)) > distanceCenterOrientation - 20
                        && distanceBetweenPoints(circles.at(i), circles.at(j)) < distanceCenterOrientation + 20 )
                {
                    // We found a robot and remove the orientation circle
                    Point2f orientationPoint = Point2f(circles.at(j).x, circles.at(j).y);

                    double orientationAngle = horizontalAngle(centerPoint, orientationPoint);
                    Point3f robPosition = Point3f(centerPoint.x, centerPoint.y, orientationAngle);
                    circles.removeAt(j--);

                    // draw circles and lines for center and orientation circles
                    Point2f directionPoint = (orientationPoint - centerPoint);
                    float scale = sqrt(directionPoint.x * directionPoint.x + directionPoint.y * directionPoint.y);
                    directionPoint.x *= ROBOT_RADIUS / scale;
                    directionPoint.y *= ROBOT_RADIUS / scale;
                    directionPoint += centerPoint;

                    if (ui->checkBoxLiveView->isChecked())
                    {
                        circle(image, scaleToGui(centerPoint),      scaleToGui(ROBOT_RADIUS),       COLOR_GREEN, 2, CV_AA);
                        circle(image, scaleToGui(orientationPoint), scaleToGui(25),  COLOR_BLUE, 1, CV_AA);
                        line  (image, scaleToGui(directionPoint),   scaleToGui(centerPoint),        COLOR_GREEN, 2, CV_AA);
                    }
                    else
                    {
                        circle(image, scaleToGui(centerPoint),      scaleToGui(ROBOT_RADIUS),       COLOR_BLUE, 2, CV_AA);
                        line  (image, scaleToGui(directionPoint),   scaleToGui(centerPoint),        COLOR_BLUE, 2, CV_AA);
                    }

                    quint8 robotCode = 0;

                    // Look for encoding circles in the vincinity
                    for (int k = j; k < circles.size(); k++)
                    {
                        if (distanceBetweenPoints( robPosition, circles.at(k) ) < searchRadius
                                && circles.at(k).z > encodingCircleMinRadius && circles.at(k).z < encodingCircleMaxRadius)
                        {
                            Point2f encodingPoint(circles.at(k).x, circles.at(k).y);
                            double encodingAngle = horizontalAngle(centerPoint, encodingPoint);
                            float compValue = qSin((encodingAngle - orientationAngle)*CV_PI/180.0);

                            if (compValue > qSin(CV_PI/2.0 - encodingCircleSector))
                            {
                                robotCode |= 1;
                            }
                            else if (compValue > qSin(-encodingCircleSector) && compValue < qSin(encodingCircleSector))
                            {
                                robotCode |= 2;
                            }
                            else if (compValue < qSin(encodingCircleSector - CV_PI/2.0))
                            {
                                robotCode |= 4;
                            }

                            if (ui->checkBoxLiveView->isChecked())
                            {
                                circle(image, scaleToGui(encodingPoint), scaleToGui(15), COLOR_RED, 1, CV_AA);
                            }

                            circles.removeAt(k--);
                        }
                    }


                    // Update robot positions according to the encoding
                    switch (robotCode)
                    {
                    case 0:
                        robotLocations[0] = robPosition; // Robot 1
                        break;
                    case 1:
                        robotLocations[1] = robPosition; // Robot 2
                        break;
                    case 5:
                        robotLocations[2] = robPosition; // Robot 3
                        break;
                    case 4:
                        robotLocations[3] = robPosition; // Robot 4
                        break;
                    default:
                        break;
                    }
                    // We break, since an orientation circle has been found
                    break;
                } // endif orientation circle found;
            } // endfor looking for orientation circles
        } // endif center circle found
    } // endfor iterating over the circles

}

QList<cv::Point3f> RobotDetectionMainWindow::eliminateCircles(QList<Point3f> circles, cv::Mat image)
{
    double borderBigToNone = (double) ui->sliderBigToNone->value();
    double borderSmallToNone = (double) ui->sliderSmallToNone->value();
    double borderDuplicate = (double) ui->sliderDuplicate->value();

    // erase circles that are too large or too small
    int tooLargeCount = 0;
    int tooSmallCount = 0;
    for (int i = 0; i < circles.size(); i++)
    {
        if(circles.at(i).z > borderBigToNone)
        {
            circles.removeAt(i--);
            tooLargeCount++;
        }
        else if(circles.at(i).z < borderSmallToNone)
        {
            circles.removeAt(i--);
            tooSmallCount++;
        }
    }

    // fuse duplicate circles
    int duplicateCount = 0;
    for (int i = 0; i < circles.size(); i++)
    {
        for (int j = i + 1; j < circles.size(); j++)
        {
            if ( distanceBetweenPoints(circles.at(i), circles.at(j)) < borderDuplicate &&
                 qAbs(circles.at(i).z - circles.at(j).z) < 20.0)
            {
                if (ui->checkBoxLiveView->isChecked())
                {
                    cv::circle(image, scaleToGui(centerOfCircle(circles.at(i))), scaleToGui(70), COLOR_DARK_GREY, 1, CV_AA);
                    cv::circle(image, scaleToGui(centerOfCircle(circles.at(j))), scaleToGui(70), COLOR_DARK_GREY, 1, CV_AA);
                }

                circles[i].x = (circles[i].x + circles[j].x) / 2.0;
                circles[i].y = (circles[i].y + circles[j].y) / 2.0;
                circles[i].z = (circles[i].z + circles[j].z) / 2.0;
                circles.removeAt(j--);

                duplicateCount++;
            }
        }

        if (ui->checkBoxLiveView->isChecked())
        {
            cv::circle(image, scaleToGui(centerOfCircle(circles.at(i))), scaleToGui(70), COLOR_CYAN, 1, CV_AA);
        }
    }


    if (ui->checkBoxLiveView->isChecked())
    {
        QString str = "Number of duplicate circles fused: ";
        str.append( QString::number( duplicateCount ) );
        str.append( "   Number of large circles erased: ");
        str.append( QString::number( tooLargeCount ) );
        str.append( "   Number of small circles erased: " );
        str.append( QString::number( tooSmallCount ) );
        str.append( "   Number of circles left: " );
        str.append( QString::number( circles.size() ) );
        ui->statusBar->showMessage(str, 200);
    }

    return circles;
}

double RobotDetectionMainWindow::distanceBetweenPoints(cv::Point2f a, cv::Point2f b)
{
    return sqrt( (a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y) );
}

double RobotDetectionMainWindow::distanceBetweenPoints(cv::Point3f a, cv::Point3f b)
{
    return sqrt( (a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y) );
}

Point2f RobotDetectionMainWindow::centerOfCircle(Point3f circle)
{
    return Point2f(circle.x, circle.y);
}



float RobotDetectionMainWindow::horizontalAngle(cv::Point2f a, cv::Point2f b)
{
    // calculate angle between line (Point a, b) and horizontal axis in degrees
    // CAUTION: bx-ax because of axis inversion in image
    // multiplication by -1 for same reason

    return -1.0 * atan2f(a.y - b.y, b.x - a.x) * 180.0 / CV_PI;
}

Point2f RobotDetectionMainWindow::scaleToGui(Point2f srcDot)
{
    return Point2f( (srcDot.x / GUI_SCALING) , (srcDot.y / GUI_SCALING) );
}

Point3f RobotDetectionMainWindow::scaleToGui(Point3f srcDot)
{
    return Point3f( (srcDot.x / GUI_SCALING) , (srcDot.y / GUI_SCALING) , (srcDot.z / GUI_SCALING));
}

double RobotDetectionMainWindow::scaleToGui(double value)
{
    return (value / GUI_SCALING);
}

void RobotDetectionMainWindow::readXmlCalibrationFile()
{
    QString fileName = "CalibrationData.xml";
    QFile* file = new QFile(fileName);

    // If file can't be found, choose other file.
    if (!file->open(QIODevice::ReadOnly | QIODevice::Text))
    {
        QMessageBox::warning(this,
                             "File Error",
                             "Couldn't find CalibrationData.xml. Please choose calibration file.",
                             QMessageBox::Ok);
        fileName = QFileDialog::getOpenFileName(this, "Load Calibration File", "", "Calibration Files (*.xml)");
        file = new QFile(fileName);

        // If file still can't be opened, show an error message.
        if (!file->open(QIODevice::ReadOnly | QIODevice::Text))
        {
            QMessageBox::critical(this,
                                  "File Error",
                                  "Couldn't open XML File",
                                  QMessageBox::Ok);
            return;
        }
    }

    QXmlStreamReader xmlReader(file);
    QList< QMap<QString, QXmlStreamAttributes> > cameraList;

    // parse until end of file or until error.
    while(!xmlReader.atEnd() && !xmlReader.hasError())
    {
        /* Read next element.*/
        QXmlStreamReader::TokenType token = xmlReader.readNext();
        /* If token is just StartDocument, we'll go to next.*/
        if(token == QXmlStreamReader::StartDocument)
        {
            continue;
        }
        if(token == QXmlStreamReader::StartElement)
        {
            // CameraCalibrationData has no data for itself
            if(xmlReader.name() == "CameraCalibrationData")
            {
                continue;
            }
            // Camera does have the data, so it is parsed
            if(xmlReader.name() == "Camera")
            {
                cameraList.append(this->parseCamera(xmlReader));
            }
        }
    }
    // Error handling
    if(xmlReader.hasError())
    {
        QMessageBox::critical(this, "Parse Error", xmlReader.errorString(), QMessageBox::Ok);
    }
    xmlReader.clear();

    for(int i = 0; i < cameraList.size(); i++)
    {
        QXmlStreamAttributes attribCamera, attribMatrix, attribLensDist, attribTrafoMatrix, attribSettings;
        attribCamera = cameraList.at(i)["Camera"];
        attribMatrix = cameraList.at(i)["Matrix"];
        attribLensDist = cameraList.at(i)["LensDistortion"];
        attribTrafoMatrix = cameraList.at(i)["TransformationMatrix"];
        attribSettings = cameraList.at(i)["Settings"];

        /*
            qDebug() << "Camera ID:" << attribCamera.value("id");
            qDebug() << "Name:" << attribCamera.value("name");
            qDebug() << "Pos:"  << attribCamera.value("pos");

            qDebug() << "fx:" << attribMatrix.value("fx");
            qDebug() << "fy:" << attribMatrix.value("fy");
            qDebug() << "cx:" << attribMatrix.value("cx");
            qDebug() << "cy:" << attribMatrix.value("cy");

            qDebug() << "p1:" << attribLensDist.value("p1");
            qDebug() << "p2:" << attribLensDist.value("p2");
            qDebug() << "k1:" << attribLensDist.value("k1");
            qDebug() << "k2:" << attribLensDist.value("k2");
            qDebug() << "k3:" << attribLensDist.value("k3");

            qDebug() << "t1:" << attribTrafoMatrix.value("t1");
            qDebug() << "t2:" << attribTrafoMatrix.value("t2");
            qDebug() << "t3:" << attribTrafoMatrix.value("t3");
            qDebug() << "t4:" << attribTrafoMatrix.value("t4");
            qDebug() << "t5:" << attribTrafoMatrix.value("t5");
            qDebug() << "t6:" << attribTrafoMatrix.value("t6");
            qDebug() << "t7:" << attribTrafoMatrix.value("t7");
            qDebug() << "t8:" << attribTrafoMatrix.value("t8");
            qDebug() << "t9:" << attribTrafoMatrix.value("t9");

            qDebug() << "brg:" << attribSettings.value("brg");
            qDebug() << "cnt:" << attribSettings.value("cnt");
            qDebug() << "exp:" << attribSettings.value("exp");
            qDebug() << " ";
            */

        // build cameraMatrix
        cameraMatrix.insert(i, Mat::eye(3, 3, CV_64F));
        cameraMatrix[i].at<double>(0, 0) = attribMatrix.value("fx").toDouble();
        cameraMatrix[i].at<double>(0, 2) = attribMatrix.value("cx").toDouble();
        cameraMatrix[i].at<double>(1, 1) = attribMatrix.value("fy").toDouble();
        cameraMatrix[i].at<double>(1, 2) = attribMatrix.value("cy").toDouble();

        // build distCoeffs
        distCoeffs.insert(i, Mat::zeros(8, 1, CV_64F));
        distCoeffs[i].at<double>(0) = attribLensDist.value("k1").toDouble();
        distCoeffs[i].at<double>(1) = attribLensDist.value("k2").toDouble();
        distCoeffs[i].at<double>(2) = attribLensDist.value("p1").toDouble();
        distCoeffs[i].at<double>(3) = attribLensDist.value("p2").toDouble();
        distCoeffs[i].at<double>(4) = attribLensDist.value("k3").toDouble();

        // build perspective transformation matrix
        perspTransfMatrix.insert(i, Mat::eye(3, 3, CV_64F));
        perspTransfMatrix[i].at<double>(0, 0) = attribTrafoMatrix.value("t1").toDouble();
        perspTransfMatrix[i].at<double>(0, 1) = attribTrafoMatrix.value("t2").toDouble();
        perspTransfMatrix[i].at<double>(0, 2) = attribTrafoMatrix.value("t3").toDouble();
        perspTransfMatrix[i].at<double>(1, 0) = attribTrafoMatrix.value("t4").toDouble();
        perspTransfMatrix[i].at<double>(1, 1) = attribTrafoMatrix.value("t5").toDouble();
        perspTransfMatrix[i].at<double>(1, 2) = attribTrafoMatrix.value("t6").toDouble();
        perspTransfMatrix[i].at<double>(2, 0) = attribTrafoMatrix.value("t7").toDouble();
        perspTransfMatrix[i].at<double>(2, 1) = attribTrafoMatrix.value("t8").toDouble();
        perspTransfMatrix[i].at<double>(2, 2) = attribTrafoMatrix.value("t9").toDouble();

        // build settings
        exposureValue.insert(i, attribSettings.value("exp").toInt());
        contrastValue.insert(i, attribSettings.value("cnt").toInt());
        brightnessValue.insert(i, attribSettings.value("brg").toInt());
        //        qDebug() << exposureValue[i] << contrastValue[i] << brightnessValue[i];
    }

    file->close();
    ui->statusBar->showMessage("XML-File was read successfully...", 2000);
}

QMap<QString, QXmlStreamAttributes> RobotDetectionMainWindow::parseCamera(QXmlStreamReader& xmlReader)
{
    QMap<QString, QXmlStreamAttributes> camera;
    if(xmlReader.tokenType() != QXmlStreamReader::StartElement && xmlReader.name() == "Camera")
    {
        return camera;
    }
    // read the attributes for Camera
    QXmlStreamAttributes attributes = xmlReader.attributes();
    // check if Camera has id attribute and add attributes to the map
    if(attributes.hasAttribute("id"))
    {
        camera.insert("Camera", xmlReader.attributes());
    }
    // Next element...
    xmlReader.readNext();

    // read until endElement by the name "Camera" occurs
    while(!(xmlReader.tokenType() == QXmlStreamReader::EndElement && xmlReader.name() == "Camera"))
    {
        if(xmlReader.tokenType() == QXmlStreamReader::StartElement)
        {
            // elements by the name "Matrix", "LensDistortion" or "Settings" are added
            camera.insert(xmlReader.name().toString(), xmlReader.attributes());
        }
        xmlReader.readNext();
    }
    return camera;
}

void RobotDetectionMainWindow::locateRobotsFromCirclesAlgo3(QList<cv::Point3f> circles)
{
    qDebug() << "-----Größe circles--------";
    qDebug() << circles.size();
    qDebug() << "-Größe Robot locationms---";
    qDebug() << robotLocations.size();

    if(circles.size()<4)
    {
        for( int i = 0;circles.size() != 4;i++)
            circles.push_back(Point3f(1, 1, 1));
    }

    for(int i = 0; i<4;i++)
    robotLocations[i] = circles[i];
    circles.clear();
}
