#ifndef ROBOTDETECTIONMAINWINDOW_H
#define ROBOTDETECTIONMAINWINDOW_H

#include <QtCore>
#include <QtGui>
#include <QMainWindow>
#include <QFileDialog>
#include <QImage>
#include <QTime>
#include <opencv2/opencv.hpp>
#include <QMessageBox>
#include <QThread>
#include <QThreadPool>
#include "myudp.h"
#include "imgtask.h"
#include "constants.h"

namespace Ui {
class RobotDetectionMainWindow;
}

class RobotDetectionMainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit RobotDetectionMainWindow(QWidget *parent = 0);
    ~RobotDetectionMainWindow();

private:
    Ui::RobotDetectionMainWindow *ui;
    MyUDP udpClient;
    int timerMilSecs;
    QTimer timer;
    QTimer timerFPS;
    QThreadPool threadPool;
    ImgTask *tasks[NR_OF_CAMS];

    QMutex workerMutex;

    QString sendToIp;
    int sendToPort;

    QList<cv::Mat> cameraMatrix;
    QList<cv::Mat> distCoeffs;
    QList<cv::Mat> perspTransfMatrix;
    QList<int> exposureValue;
    QList<int> contrastValue;
    QList<int> brightnessValue;
    QList<cv::Point3f> robotLocations;
    cv::VideoCapture videoCapture[NR_OF_CAMS];
    cv::Mat cameraImages[NR_OF_CAMS];
    cv::Mat originalImages[NR_OF_CAMS];
    // cv::Mat testImage;
    bool mainloopIsActive;
    int fpsCount;
    QTime timeStamp;
protected:
    void writeRobotLocationsToTable();
    void writeRobotIDsToGui(cv::Mat guiImage);
    void locateRobotsFromCirclesAlgo1(cv::Mat image, QList<cv::Point3f> circles);
    void locateRobotsFromCirclesAlgo2(cv::Mat image, QList<cv::Point3f> circles);
    void locateRobotsFromCirclesAlgo3(QList<cv::Point3f> circles);

    QList<cv::Point3f> eliminateCircles (QList<cv::Point3f> circles, cv::Mat image);

    double distanceBetweenPoints(cv::Point2f a, cv::Point2f b);
    double distanceBetweenPoints(cv::Point3f a, cv::Point3f b);
    cv::Point2f centerOfCircle(cv::Point3f circle);
    float horizontalAngle(cv::Point2f a, cv::Point2f b);
    cv::Point2f scaleToGui(cv::Point2f srcDot);
    cv::Point3f scaleToGui(cv::Point3f srcDot);
    double      scaleToGui(double value);
    void readXmlCalibrationFile();
    QMap<QString, QXmlStreamAttributes> parseCamera(QXmlStreamReader& xmlReader);
    static bool radiusIsSmaller(cv::Point3f a, cv::Point3f b)
    {
        return (a.z > b.z);
    }


private slots:
    void on_pushButtonStartStop_clicked();
    void operate();
    void fpsCounter();

};

#endif // ROBOTDETECTIONMAINWINDOW_H
