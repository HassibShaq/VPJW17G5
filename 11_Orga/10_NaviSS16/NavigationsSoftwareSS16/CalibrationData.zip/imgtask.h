#ifndef IMGTASK_H
#define IMGTASK_H
#include <QVector>
#include <QThreadPool>
#include <QRunnable>
#include <QtCore>
#include <opencv2/opencv.hpp>
#include <opencv2/aruco.hpp>
#include "constants.h"
#include <QDebug>
#include <newfunction.h>

class ImgTask : public QRunnable
{
public:
    void run();
    void setImage(cv::Mat image);
    void setCameraMatrix(cv::Mat cameraMatrix);
    void setDistCoeffs(cv::Mat distCoeffs);
    void setPerspTransfMatrix(cv::Mat perspTransfMatrix);
    void setThresh(int thresh);
    void setDebugMode(bool liveViewMode);
    QList<cv::Point3f> getCircles();
    cv::Mat getWarpedImage();

protected:
    cv::Mat image;
    cv::Mat cameraMatrix;
    cv::Mat distCoeffs;
    cv::Mat perspTransfMatrix;
    cv::Mat guiTransfMatrix;
    cv::Mat warpedImage;
    int thresh;
    bool liveViewMode; // debug == LiveView mode...
    QList<cv::Point3f> circles;

signals:

public slots:
};

#endif // IMGTASK_H
