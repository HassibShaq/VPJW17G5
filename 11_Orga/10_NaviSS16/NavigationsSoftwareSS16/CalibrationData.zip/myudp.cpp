/****************************************************************************
 * This class provides methods for sending robot positions and timestamps
 * via UDP.
 *
 * Filename: myudp.cpp
 * Author:   Markus Baden
 * Created:  2013-03-14
 * Changed:  2014-04-10
 ***************************************************************************/

#include "myudp.h"

MyUDP::MyUDP(QObject *parent) : QObject(parent)
{

}

void MyUDP::setSendIP(QString sendToIp, int sendToPort)
{
    this->sendIP = sendToIp;
    this->sendPort = sendToPort;

    /*
     * We do not bind to the socket, as we do not intend to receive any data

    socket.bind(QHostAddress(sendIP), sendPort);

    connect(&socket,
            SIGNAL(readyRead()),
            this,
            SLOT(readReady()));
     */
}

void MyUDP::sendUdpData( QList<cv::Point3f> robotLocations, int numberOfRobots, QTime timeStamp)
{
    /// All values are converted to datatype double prior to sending. This is to make
    /// sure the Robotinos running Matlab/XPC-Target receive the data correctly.
    ///
    /// double values 1-24 are reserved for a maximum of 8 robot positions
    /// double values 25-27 contain a time stamp

    QByteArray message;
    double x, y, phi, hour, minute, second;

    for(int i = 0; i < numberOfRobots; i++)
    {
        x = robotLocations.at(i).x;
        y = robotLocations.at(i).y;
        phi = robotLocations.at(i).z / 180.0 * CV_PI; // orientation angle in radiant
        message.append( (const char*) &x, sizeof(double));
        message.append( (const char*) &y, sizeof(double));
        message.append( (const char*) &phi, sizeof(double));
    }

    /// fill message with more values ("robots 5-8") (to be consistent with the old Matlab solution)
    /// this might be removed later
    for(int i = 0; i < numberOfRobots; i++)
    {
        x = robotLocations.at(i).x;
        y = robotLocations.at(i).y;
        phi = robotLocations.at(i).z / 180.0 * CV_PI; // orientation angle in radiant
        message.append( (const char*) &x, sizeof(double));
        message.append( (const char*) &y, sizeof(double));
        message.append( (const char*) &phi, sizeof(double));
    }

    /// append timestamp to message
    hour = timeStamp.hour();
    minute = timeStamp.minute();
    second = timeStamp.second() + (0.001 * timeStamp.msec());
    message.append( (const char*) &hour, sizeof(double));
    message.append( (const char*) &minute, sizeof(double));
    message.append( (const char*) &second, sizeof(double));



    ///EXTRA DATA------------------------------------------------------------------------------------------------------BW
    double my_var_ms = 9.9876;
    message.append( (const char*) &my_var_ms, sizeof(double));

    message.append( (const char*) &second, sizeof(double));

    /// fill message with zeroes (to be consistent with the old Matlab solution)
    /// this might be removed later
    double dummy = 0.0;
    for (int i = 30; i <= 56; i++)
    {
        message.append( (const char*) &dummy, sizeof(double));
    }

    /// send message
    socket.writeDatagram(message, QHostAddress(sendIP), sendPort);

    // clean up
    message.clear();
}

void MyUDP::readReady()
{
    QByteArray buffer;
    buffer.resize(socket.pendingDatagramSize());
    QHostAddress sender;
    quint16 port;
    socket.readDatagram(buffer.data(), buffer.size(), &sender, &port);

    qDebug() << "Message From: " << sender.toString();
    qDebug() << "With Port Number " << port;
    qDebug() << "Message: " << buffer;
}
