/********************************************************************************
** Form generated from reading UI file 'robotdetectionmainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.1.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ROBOTDETECTIONMAINWINDOW_H
#define UI_ROBOTDETECTIONMAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_RobotDetectionMainWindow
{
public:
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QLabel *labelLogo;
    QLabel *labelImage;
    QTabWidget *tabWidget;
    QWidget *tab_3;
    QGridLayout *gridLayout_3;
    QPushButton *pushButtonStartStop;
    QCheckBox *checkBoxLiveView;
    QCheckBox *checkBoxNewAlgo;
    QLabel *labelFPS;
    QSpacerItem *horizontalSpacer;
    QSpacerItem *verticalSpacer_3;
    QSpacerItem *verticalSpacer_2;
    QWidget *tab;
    QVBoxLayout *verticalLayout;
    QTableWidget *tableWidget;
    QLabel *labelVersion;
    QWidget *tab_2;
    QGridLayout *gridLayout_4;
    QVBoxLayout *verticalLayout_5;
    QHBoxLayout *horizontalLayout_11;
    QLabel *labelMiddleMin;
    QLabel *labelMiddleMinValue;
    QSlider *sliderMiddleToSmall;
    QHBoxLayout *horizontalLayout_4;
    QLabel *labelSmallNone;
    QLabel *labelSmallNoneValue;
    QSlider *sliderSmallToNone;
    QSpacerItem *verticalSpacer_7;
    QHBoxLayout *horizontalLayout_2;
    QLabel *labelSliderThreshold;
    QLabel *labelThreshold;
    QSlider *sliderThreshold;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout_5;
    QLabel *labelBigNone;
    QLabel *labelBigNoneValue;
    QSlider *sliderBigToNone;
    QHBoxLayout *horizontalLayout_10;
    QLabel *labelMaxMiddle;
    QLabel *labelMaxMiddleValue;
    QSlider *sliderBigToMiddle;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_6;
    QLabel *labelCodingAngle;
    QLabel *labelCodingAngleValue;
    QSlider *sliderCodingAngle;
    QHBoxLayout *horizontalLayout_3;
    QLabel *labelDuplicate;
    QLabel *labelDuplicateValue;
    QSlider *sliderDuplicate;
    QSpacerItem *verticalSpacer_6;
    QSpacerItem *horizontalSpacer_2;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *RobotDetectionMainWindow)
    {
        if (RobotDetectionMainWindow->objectName().isEmpty())
            RobotDetectionMainWindow->setObjectName(QStringLiteral("RobotDetectionMainWindow"));
        RobotDetectionMainWindow->resize(1298, 921);
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(RobotDetectionMainWindow->sizePolicy().hasHeightForWidth());
        RobotDetectionMainWindow->setSizePolicy(sizePolicy);
        QIcon icon;
        icon.addFile(QStringLiteral(":/images/Hawhamburg-logo.png"), QSize(), QIcon::Normal, QIcon::Off);
        RobotDetectionMainWindow->setWindowIcon(icon);
        centralWidget = new QWidget(RobotDetectionMainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        labelLogo = new QLabel(centralWidget);
        labelLogo->setObjectName(QStringLiteral("labelLogo"));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(labelLogo->sizePolicy().hasHeightForWidth());
        labelLogo->setSizePolicy(sizePolicy1);
        labelLogo->setMaximumSize(QSize(16777215, 221));
        labelLogo->setFrameShape(QFrame::StyledPanel);
        labelLogo->setFrameShadow(QFrame::Sunken);
        labelLogo->setPixmap(QPixmap(QString::fromUtf8(":/images/HAW_Hamburg.png")));
        labelLogo->setScaledContents(false);
        labelLogo->setWordWrap(false);

        gridLayout->addWidget(labelLogo, 1, 2, 1, 3);

        labelImage = new QLabel(centralWidget);
        labelImage->setObjectName(QStringLiteral("labelImage"));
        QSizePolicy sizePolicy2(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(10);
        sizePolicy2.setHeightForWidth(labelImage->sizePolicy().hasHeightForWidth());
        labelImage->setSizePolicy(sizePolicy2);
        labelImage->setMinimumSize(QSize(1280, 640));
        labelImage->setMaximumSize(QSize(1280, 640));
        labelImage->setFrameShape(QFrame::StyledPanel);
        labelImage->setFrameShadow(QFrame::Sunken);

        gridLayout->addWidget(labelImage, 3, 0, 1, 5);

        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        QSizePolicy sizePolicy3(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(tabWidget->sizePolicy().hasHeightForWidth());
        tabWidget->setSizePolicy(sizePolicy3);
        tabWidget->setMaximumSize(QSize(401, 221));
        tabWidget->setTabShape(QTabWidget::Rounded);
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        gridLayout_3 = new QGridLayout(tab_3);
        gridLayout_3->setSpacing(6);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        pushButtonStartStop = new QPushButton(tab_3);
        pushButtonStartStop->setObjectName(QStringLiteral("pushButtonStartStop"));

        gridLayout_3->addWidget(pushButtonStartStop, 0, 0, 1, 1);

        checkBoxLiveView = new QCheckBox(tab_3);
        checkBoxLiveView->setObjectName(QStringLiteral("checkBoxLiveView"));

        gridLayout_3->addWidget(checkBoxLiveView, 3, 0, 1, 1);

        checkBoxNewAlgo = new QCheckBox(tab_3);
        checkBoxNewAlgo->setObjectName(QStringLiteral("checkBoxNewAlgo"));
        checkBoxNewAlgo->setChecked(true);

        gridLayout_3->addWidget(checkBoxNewAlgo, 4, 0, 1, 1);

        labelFPS = new QLabel(tab_3);
        labelFPS->setObjectName(QStringLiteral("labelFPS"));
        QSizePolicy sizePolicy4(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(labelFPS->sizePolicy().hasHeightForWidth());
        labelFPS->setSizePolicy(sizePolicy4);
        labelFPS->setMinimumSize(QSize(170, 0));

        gridLayout_3->addWidget(labelFPS, 1, 0, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer, 4, 1, 1, 1);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_3->addItem(verticalSpacer_3, 5, 0, 1, 1);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_3->addItem(verticalSpacer_2, 2, 0, 1, 1);

        tabWidget->addTab(tab_3, QString());
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        verticalLayout = new QVBoxLayout(tab);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        tableWidget = new QTableWidget(tab);
        if (tableWidget->columnCount() < 3)
            tableWidget->setColumnCount(3);
        QFont font;
        font.setFamily(QStringLiteral("MS Shell Dlg 2"));
        font.setPointSize(8);
        font.setBold(false);
        font.setWeight(50);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        __qtablewidgetitem->setFont(font);
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QFont font1;
        font1.setFamily(QStringLiteral("MS Shell Dlg 2"));
        font1.setPointSize(8);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        __qtablewidgetitem1->setFont(font1);
        tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        __qtablewidgetitem2->setFont(font1);
        tableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        if (tableWidget->rowCount() < 4)
            tableWidget->setRowCount(4);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        __qtablewidgetitem3->setFont(font);
        tableWidget->setVerticalHeaderItem(0, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        __qtablewidgetitem4->setFont(font);
        tableWidget->setVerticalHeaderItem(1, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        __qtablewidgetitem5->setFont(font);
        tableWidget->setVerticalHeaderItem(2, __qtablewidgetitem5);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        __qtablewidgetitem6->setFont(font);
        tableWidget->setVerticalHeaderItem(3, __qtablewidgetitem6);
        tableWidget->setObjectName(QStringLiteral("tableWidget"));
        sizePolicy4.setHeightForWidth(tableWidget->sizePolicy().hasHeightForWidth());
        tableWidget->setSizePolicy(sizePolicy4);
        tableWidget->setMinimumSize(QSize(363, 148));
        tableWidget->setMaximumSize(QSize(363, 148));
        QFont font2;
        font2.setPointSize(14);
        tableWidget->setFont(font2);
        tableWidget->horizontalHeader()->setMinimumSectionSize(30);

        verticalLayout->addWidget(tableWidget);

        labelVersion = new QLabel(tab);
        labelVersion->setObjectName(QStringLiteral("labelVersion"));

        verticalLayout->addWidget(labelVersion);

        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        gridLayout_4 = new QGridLayout(tab_2);
        gridLayout_4->setSpacing(6);
        gridLayout_4->setContentsMargins(11, 11, 11, 11);
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setSpacing(3);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setSpacing(6);
        horizontalLayout_11->setObjectName(QStringLiteral("horizontalLayout_11"));
        labelMiddleMin = new QLabel(tab_2);
        labelMiddleMin->setObjectName(QStringLiteral("labelMiddleMin"));
        sizePolicy4.setHeightForWidth(labelMiddleMin->sizePolicy().hasHeightForWidth());
        labelMiddleMin->setSizePolicy(sizePolicy4);
        labelMiddleMin->setMinimumSize(QSize(160, 0));

        horizontalLayout_11->addWidget(labelMiddleMin);

        labelMiddleMinValue = new QLabel(tab_2);
        labelMiddleMinValue->setObjectName(QStringLiteral("labelMiddleMinValue"));

        horizontalLayout_11->addWidget(labelMiddleMinValue);


        verticalLayout_5->addLayout(horizontalLayout_11);

        sliderMiddleToSmall = new QSlider(tab_2);
        sliderMiddleToSmall->setObjectName(QStringLiteral("sliderMiddleToSmall"));
        sliderMiddleToSmall->setMinimum(10);
        sliderMiddleToSmall->setMaximum(30);
        sliderMiddleToSmall->setValue(20);
        sliderMiddleToSmall->setOrientation(Qt::Horizontal);

        verticalLayout_5->addWidget(sliderMiddleToSmall);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        horizontalLayout_4->setSizeConstraint(QLayout::SetMinimumSize);
        labelSmallNone = new QLabel(tab_2);
        labelSmallNone->setObjectName(QStringLiteral("labelSmallNone"));
        sizePolicy4.setHeightForWidth(labelSmallNone->sizePolicy().hasHeightForWidth());
        labelSmallNone->setSizePolicy(sizePolicy4);
        labelSmallNone->setMinimumSize(QSize(160, 0));

        horizontalLayout_4->addWidget(labelSmallNone);

        labelSmallNoneValue = new QLabel(tab_2);
        labelSmallNoneValue->setObjectName(QStringLiteral("labelSmallNoneValue"));
        QSizePolicy sizePolicy5(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy5.setHorizontalStretch(0);
        sizePolicy5.setVerticalStretch(0);
        sizePolicy5.setHeightForWidth(labelSmallNoneValue->sizePolicy().hasHeightForWidth());
        labelSmallNoneValue->setSizePolicy(sizePolicy5);

        horizontalLayout_4->addWidget(labelSmallNoneValue);


        verticalLayout_5->addLayout(horizontalLayout_4);

        sliderSmallToNone = new QSlider(tab_2);
        sliderSmallToNone->setObjectName(QStringLiteral("sliderSmallToNone"));
        sizePolicy5.setHeightForWidth(sliderSmallToNone->sizePolicy().hasHeightForWidth());
        sliderSmallToNone->setSizePolicy(sizePolicy5);
        sliderSmallToNone->setMinimumSize(QSize(0, 0));
        sliderSmallToNone->setMinimum(5);
        sliderSmallToNone->setMaximum(20);
        sliderSmallToNone->setValue(10);
        sliderSmallToNone->setOrientation(Qt::Horizontal);

        verticalLayout_5->addWidget(sliderSmallToNone);

        verticalSpacer_7 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_5->addItem(verticalSpacer_7);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        labelSliderThreshold = new QLabel(tab_2);
        labelSliderThreshold->setObjectName(QStringLiteral("labelSliderThreshold"));
        sizePolicy4.setHeightForWidth(labelSliderThreshold->sizePolicy().hasHeightForWidth());
        labelSliderThreshold->setSizePolicy(sizePolicy4);
        labelSliderThreshold->setMinimumSize(QSize(160, 0));

        horizontalLayout_2->addWidget(labelSliderThreshold);

        labelThreshold = new QLabel(tab_2);
        labelThreshold->setObjectName(QStringLiteral("labelThreshold"));
        sizePolicy5.setHeightForWidth(labelThreshold->sizePolicy().hasHeightForWidth());
        labelThreshold->setSizePolicy(sizePolicy5);

        horizontalLayout_2->addWidget(labelThreshold);


        verticalLayout_5->addLayout(horizontalLayout_2);

        sliderThreshold = new QSlider(tab_2);
        sliderThreshold->setObjectName(QStringLiteral("sliderThreshold"));
        sizePolicy5.setHeightForWidth(sliderThreshold->sizePolicy().hasHeightForWidth());
        sliderThreshold->setSizePolicy(sizePolicy5);
        sliderThreshold->setMaximum(255);
        sliderThreshold->setValue(110);
        sliderThreshold->setOrientation(Qt::Horizontal);

        verticalLayout_5->addWidget(sliderThreshold);


        gridLayout_4->addLayout(verticalLayout_5, 0, 0, 1, 1);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setSpacing(3);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        labelBigNone = new QLabel(tab_2);
        labelBigNone->setObjectName(QStringLiteral("labelBigNone"));
        sizePolicy4.setHeightForWidth(labelBigNone->sizePolicy().hasHeightForWidth());
        labelBigNone->setSizePolicy(sizePolicy4);
        labelBigNone->setMinimumSize(QSize(160, 0));

        horizontalLayout_5->addWidget(labelBigNone);

        labelBigNoneValue = new QLabel(tab_2);
        labelBigNoneValue->setObjectName(QStringLiteral("labelBigNoneValue"));
        sizePolicy5.setHeightForWidth(labelBigNoneValue->sizePolicy().hasHeightForWidth());
        labelBigNoneValue->setSizePolicy(sizePolicy5);

        horizontalLayout_5->addWidget(labelBigNoneValue);


        verticalLayout_3->addLayout(horizontalLayout_5);

        sliderBigToNone = new QSlider(tab_2);
        sliderBigToNone->setObjectName(QStringLiteral("sliderBigToNone"));
        sizePolicy5.setHeightForWidth(sliderBigToNone->sizePolicy().hasHeightForWidth());
        sliderBigToNone->setSizePolicy(sizePolicy5);
        sliderBigToNone->setMinimumSize(QSize(0, 0));
        sliderBigToNone->setMinimum(30);
        sliderBigToNone->setMaximum(80);
        sliderBigToNone->setValue(40);
        sliderBigToNone->setOrientation(Qt::Horizontal);

        verticalLayout_3->addWidget(sliderBigToNone);

        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setSpacing(6);
        horizontalLayout_10->setObjectName(QStringLiteral("horizontalLayout_10"));
        labelMaxMiddle = new QLabel(tab_2);
        labelMaxMiddle->setObjectName(QStringLiteral("labelMaxMiddle"));
        sizePolicy4.setHeightForWidth(labelMaxMiddle->sizePolicy().hasHeightForWidth());
        labelMaxMiddle->setSizePolicy(sizePolicy4);
        labelMaxMiddle->setMinimumSize(QSize(160, 0));

        horizontalLayout_10->addWidget(labelMaxMiddle);

        labelMaxMiddleValue = new QLabel(tab_2);
        labelMaxMiddleValue->setObjectName(QStringLiteral("labelMaxMiddleValue"));

        horizontalLayout_10->addWidget(labelMaxMiddleValue);


        verticalLayout_3->addLayout(horizontalLayout_10);

        sliderBigToMiddle = new QSlider(tab_2);
        sliderBigToMiddle->setObjectName(QStringLiteral("sliderBigToMiddle"));
        sliderBigToMiddle->setMinimum(20);
        sliderBigToMiddle->setMaximum(40);
        sliderBigToMiddle->setPageStep(10);
        sliderBigToMiddle->setValue(30);
        sliderBigToMiddle->setOrientation(Qt::Horizontal);

        verticalLayout_3->addWidget(sliderBigToMiddle);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_3->addItem(verticalSpacer);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        horizontalLayout_6->setSizeConstraint(QLayout::SetDefaultConstraint);
        labelCodingAngle = new QLabel(tab_2);
        labelCodingAngle->setObjectName(QStringLiteral("labelCodingAngle"));
        sizePolicy4.setHeightForWidth(labelCodingAngle->sizePolicy().hasHeightForWidth());
        labelCodingAngle->setSizePolicy(sizePolicy4);
        labelCodingAngle->setMinimumSize(QSize(160, 0));

        horizontalLayout_6->addWidget(labelCodingAngle);

        labelCodingAngleValue = new QLabel(tab_2);
        labelCodingAngleValue->setObjectName(QStringLiteral("labelCodingAngleValue"));
        sizePolicy5.setHeightForWidth(labelCodingAngleValue->sizePolicy().hasHeightForWidth());
        labelCodingAngleValue->setSizePolicy(sizePolicy5);

        horizontalLayout_6->addWidget(labelCodingAngleValue);


        verticalLayout_3->addLayout(horizontalLayout_6);

        sliderCodingAngle = new QSlider(tab_2);
        sliderCodingAngle->setObjectName(QStringLiteral("sliderCodingAngle"));
        sliderCodingAngle->setMinimum(5);
        sliderCodingAngle->setMaximum(90);
        sliderCodingAngle->setPageStep(10);
        sliderCodingAngle->setValue(30);
        sliderCodingAngle->setOrientation(Qt::Horizontal);

        verticalLayout_3->addWidget(sliderCodingAngle);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        horizontalLayout_3->setSizeConstraint(QLayout::SetDefaultConstraint);
        labelDuplicate = new QLabel(tab_2);
        labelDuplicate->setObjectName(QStringLiteral("labelDuplicate"));
        sizePolicy4.setHeightForWidth(labelDuplicate->sizePolicy().hasHeightForWidth());
        labelDuplicate->setSizePolicy(sizePolicy4);
        labelDuplicate->setMinimumSize(QSize(160, 0));

        horizontalLayout_3->addWidget(labelDuplicate);

        labelDuplicateValue = new QLabel(tab_2);
        labelDuplicateValue->setObjectName(QStringLiteral("labelDuplicateValue"));
        sizePolicy5.setHeightForWidth(labelDuplicateValue->sizePolicy().hasHeightForWidth());
        labelDuplicateValue->setSizePolicy(sizePolicy5);

        horizontalLayout_3->addWidget(labelDuplicateValue);


        verticalLayout_3->addLayout(horizontalLayout_3);

        sliderDuplicate = new QSlider(tab_2);
        sliderDuplicate->setObjectName(QStringLiteral("sliderDuplicate"));
        sizePolicy5.setHeightForWidth(sliderDuplicate->sizePolicy().hasHeightForWidth());
        sliderDuplicate->setSizePolicy(sizePolicy5);
        sliderDuplicate->setMinimumSize(QSize(0, 0));
        sliderDuplicate->setMinimum(1);
        sliderDuplicate->setMaximum(150);
        sliderDuplicate->setSingleStep(0);
        sliderDuplicate->setValue(40);
        sliderDuplicate->setOrientation(Qt::Horizontal);

        verticalLayout_3->addWidget(sliderDuplicate);


        gridLayout_4->addLayout(verticalLayout_3, 0, 1, 1, 1);

        verticalSpacer_6 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_4->addItem(verticalSpacer_6, 1, 0, 1, 2);

        tabWidget->addTab(tab_2, QString());

        gridLayout->addWidget(tabWidget, 1, 0, 1, 1);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_2, 1, 1, 1, 1);

        RobotDetectionMainWindow->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(RobotDetectionMainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        RobotDetectionMainWindow->setStatusBar(statusBar);

        retranslateUi(RobotDetectionMainWindow);
        QObject::connect(sliderSmallToNone, SIGNAL(valueChanged(int)), labelSmallNoneValue, SLOT(setNum(int)));
        QObject::connect(sliderMiddleToSmall, SIGNAL(valueChanged(int)), labelMiddleMinValue, SLOT(setNum(int)));

        tabWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(RobotDetectionMainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *RobotDetectionMainWindow)
    {
        RobotDetectionMainWindow->setWindowTitle(QApplication::translate("RobotDetectionMainWindow", "Robot Detection", 0));
#ifndef QT_NO_TOOLTIP
        labelLogo->setToolTip(QApplication::translate("RobotDetectionMainWindow", "Gewerk 5 FTW !!!", 0));
#endif // QT_NO_TOOLTIP
        labelLogo->setText(QString());
        labelImage->setText(QString());
#ifndef QT_NO_TOOLTIP
        pushButtonStartStop->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        pushButtonStartStop->setText(QApplication::translate("RobotDetectionMainWindow", "Start Detection", 0));
#ifndef QT_NO_TOOLTIP
        checkBoxLiveView->setToolTip(QApplication::translate("RobotDetectionMainWindow", "activates live view mode with lower framerate", 0));
#endif // QT_NO_TOOLTIP
        checkBoxLiveView->setText(QApplication::translate("RobotDetectionMainWindow", "Live View", 0));
        checkBoxNewAlgo->setText(QApplication::translate("RobotDetectionMainWindow", "Use new algorithm", 0));
        labelFPS->setText(QApplication::translate("RobotDetectionMainWindow", "Frames per second:", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("RobotDetectionMainWindow", "Controls", 0));
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("RobotDetectionMainWindow", "x", 0));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("RobotDetectionMainWindow", "y", 0));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("RobotDetectionMainWindow", "phi", 0));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget->verticalHeaderItem(0);
        ___qtablewidgetitem3->setText(QApplication::translate("RobotDetectionMainWindow", "Robot 1", 0));
        QTableWidgetItem *___qtablewidgetitem4 = tableWidget->verticalHeaderItem(1);
        ___qtablewidgetitem4->setText(QApplication::translate("RobotDetectionMainWindow", "Robot 2", 0));
        QTableWidgetItem *___qtablewidgetitem5 = tableWidget->verticalHeaderItem(2);
        ___qtablewidgetitem5->setText(QApplication::translate("RobotDetectionMainWindow", "Robot 3", 0));
        QTableWidgetItem *___qtablewidgetitem6 = tableWidget->verticalHeaderItem(3);
        ___qtablewidgetitem6->setText(QApplication::translate("RobotDetectionMainWindow", "Robot 4", 0));
        labelVersion->setText(QApplication::translate("RobotDetectionMainWindow", "TextLabel", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("RobotDetectionMainWindow", "Localization", 0));
        labelMiddleMin->setText(QApplication::translate("RobotDetectionMainWindow", "Middle to Minimum Separation:", 0));
        labelMiddleMinValue->setText(QApplication::translate("RobotDetectionMainWindow", "0", 0));
        labelSmallNone->setText(QApplication::translate("RobotDetectionMainWindow", "Minimum Circle Radius:", 0));
#ifndef QT_NO_TOOLTIP
        labelSmallNoneValue->setToolTip(QApplication::translate("RobotDetectionMainWindow", "millimeters", 0));
#endif // QT_NO_TOOLTIP
        labelSmallNoneValue->setText(QApplication::translate("RobotDetectionMainWindow", "0", 0));
#ifndef QT_NO_TOOLTIP
        sliderSmallToNone->setToolTip(QApplication::translate("RobotDetectionMainWindow", "minimum radius for smallest circles", 0));
#endif // QT_NO_TOOLTIP
        labelSliderThreshold->setText(QApplication::translate("RobotDetectionMainWindow", "Contour Threshold:", 0));
        labelThreshold->setText(QApplication::translate("RobotDetectionMainWindow", "0", 0));
#ifndef QT_NO_TOOLTIP
        sliderThreshold->setToolTip(QApplication::translate("RobotDetectionMainWindow", "threshold value for contour detection", 0));
#endif // QT_NO_TOOLTIP
        labelBigNone->setText(QApplication::translate("RobotDetectionMainWindow", "Maximum Circle Radius:", 0));
#ifndef QT_NO_TOOLTIP
        labelBigNoneValue->setToolTip(QApplication::translate("RobotDetectionMainWindow", "millimeters", 0));
#endif // QT_NO_TOOLTIP
        labelBigNoneValue->setText(QApplication::translate("RobotDetectionMainWindow", "0", 0));
#ifndef QT_NO_TOOLTIP
        sliderBigToNone->setToolTip(QApplication::translate("RobotDetectionMainWindow", "maximum radius for largest circles", 0));
#endif // QT_NO_TOOLTIP
        labelMaxMiddle->setText(QApplication::translate("RobotDetectionMainWindow", "Maximum to Middle Separation:", 0));
        labelMaxMiddleValue->setText(QApplication::translate("RobotDetectionMainWindow", "0", 0));
        labelCodingAngle->setText(QApplication::translate("RobotDetectionMainWindow", "Maximum Angle for Encoding:", 0));
#ifndef QT_NO_TOOLTIP
        labelCodingAngleValue->setToolTip(QApplication::translate("RobotDetectionMainWindow", "millimeters", 0));
#endif // QT_NO_TOOLTIP
        labelCodingAngleValue->setText(QApplication::translate("RobotDetectionMainWindow", "0", 0));
        labelDuplicate->setText(QApplication::translate("RobotDetectionMainWindow", "Closest Circle Distance:", 0));
#ifndef QT_NO_TOOLTIP
        labelDuplicateValue->setToolTip(QApplication::translate("RobotDetectionMainWindow", "millimeters", 0));
#endif // QT_NO_TOOLTIP
        labelDuplicateValue->setText(QApplication::translate("RobotDetectionMainWindow", "0", 0));
#ifndef QT_NO_TOOLTIP
        sliderDuplicate->setToolTip(QApplication::translate("RobotDetectionMainWindow", "a circle closer to another circle than this value is ignored", 0));
#endif // QT_NO_TOOLTIP
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("RobotDetectionMainWindow", "Settings", 0));
    } // retranslateUi

};

namespace Ui {
    class RobotDetectionMainWindow: public Ui_RobotDetectionMainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ROBOTDETECTIONMAINWINDOW_H
