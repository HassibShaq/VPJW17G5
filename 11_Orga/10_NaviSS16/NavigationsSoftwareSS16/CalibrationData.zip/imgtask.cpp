/****************************************************************************
 * This class provides methods to find circles from camera images in seperate
 * tasks. The contours of the image are undistorted and the perspective
 * Transformation is applied.
 * Undistorting and Perspective Warping can also be applied to the whole
 * image for Debug/LiveView purposes.
 *
 * Filename: imgtask.cpp
 * Author:   Markus Baden
 * Revised by: Jochen Maaß
 * Created:  2014-03-27
 * Changed:  2015-10-14
 ***************************************************************************/

#include "imgtask.h"
#include "newfunction.h"
using namespace cv;

void ImgTask::run()
{
    if(image.cols < 1)
    {
        return;
    }

    // create work copy to be able to draw into the original image
    Mat workImage = image.clone();
    // PROCESS IMAGE
    cvtColor(workImage, workImage, CV_BGR2GRAY);                //Grauwert?
    ///GaussianBlur(workImage, workImage, cv::Size(3, 3), 2, 2); //Glättungsfilter
    threshold(workImage, workImage, thresh, 255, THRESH_BINARY);//Definiert den Schwellwert auf 255

    // FIND CONTOURS IN SINGLE FRAME
///    std::vector<std::vector<Point> > contours;
       std::vector<std::vector<Point2f> > warpedCorners;
///    std::vector<std::vector<Point2f> > validContours;
///    std::vector<Vec4i> hierarchy;

////////////////////////////////////////////////////////////////////////////////////////////////////
///
///
    //New Variables
    double angle = 0.0;
    int n;
    int quadrant;

    //Aruco Options
    aruco::Dictionary dictionary = aruco::getPredefinedDictionary(aruco::DICT_ARUCO_ORIGINAL);
    aruco::DetectorParameters parameters;
    std::vector<std::vector<Point2f>> rejectedCandidates;
    //parameters.doCornerRefinement = true;           //Subpixelverbesserung
    //parameters.cornerRefinementMaxIterations = 100; //Anzahl der Wiederholungen f. Kantenerkennung
    //parameters.cornerRefinementMinAccuracy = 0.01;  //Minimale Abweichung
    //parameters.minMarkerPerimeterRate = 0.03;       //default: 0.03
    //parameters.errorCorrectionRate = 0.6;           //default: 0.6
    //parameters.cornerRefinementMaxIterations = 30;  //default: 30

    std::vector< std::vector<Point2f> > markerCorners;

    std::vector<int> markerIds;

    //Eingangsbild, Bibliothek, alle vier Kanten eines jeden Markers, Die ID´s der Marker, nicht beachtete Marker.
    //qDebug() << "vordetect";
    cv::aruco::detectMarkers(workImage, dictionary, markerCorners, markerIds, parameters, rejectedCandidates);
    qDebug() << markerIds.size();
    aruco::drawDetectedMarkers(image, markerCorners, markerIds);
///
///
///
////////////////////////////////////////////////////////////////////////////////////////////////////



/// for( unsigned int j = 0; j < contours.size(); j++ )
    for( unsigned int j = 0; j < markerIds.size(); j++ )
    {
        std::vector<Point2f> tempVec, tempVec2;
        tempVec = markerCorners[j];

        // APPLY CAMERA CALIBRATION DATA
        // undistortPoints needs cameraMatrix twice (second time as projection matrix P)
        // otherwise the destination points are not calculated correctly
        // this is not a bug in OpenCV as first thought, but rather a poorly documented function
        undistortPoints(tempVec, tempVec2, cameraMatrix, distCoeffs, noArray(), cameraMatrix);

        // APPLY PERSPECTIVE TRANSFORM
        perspectiveTransform(tempVec2, tempVec, perspTransfMatrix);
        warpedCorners.push_back(tempVec);
    }

    if (liveViewMode)	// also called LiveView-Mode
    {
        // Undistort Image
        Mat temp;
        undistort(image, temp, cameraMatrix, distCoeffs);

        // APPLY PERSPECTIVE TRANSFORM
        warpPerspective(temp, warpedImage, guiTransfMatrix, Size(GUI_WIDTH, GUI_HEIGTH), INTER_NEAREST, BORDER_CONSTANT, 0);
    }

    //Sort the ID´s and Corners by ID Order
    sortbyfirstvector(&markerIds, &warpedCorners);

    //Calculate Angle and Position of all detected Marker
    double tempangle;
    double angleMiddleValue;
    cv::Point2f position;
    int t = 0;
    for( unsigned int i = 0;i<markerIds.size();i++)
    {

        //Calculate Angle of detected Marker
        for( unsigned int a = 0; a<MAX_NR_OF_ROBOTS*2; a++)
        {
            //Current ID is in a
            if(markerIds[i] == a)
            {

                //Calculate the Angle from Marker i
                tempangle = calculateangle(warpedCorners[i], quadrant);
                angle = angle + tempangle;
                n++;

                //is the current ID not even, check the second (paired) marker
                if((a/2)% 2 != 0)
                {
                    //If the second marker (paired from even Marker) also exists
                    t = i;
                    if(t-1 >= 0)
                    if(markerIds[t-1] == a-1)
                    {
                        //Calculate Angle between booth marker
                        tempangle = calculateanglebetweenmarker(warpedCorners[i-1],warpedCorners[i]);
                        angle = angle + tempangle;
                        n++;

                        //Calculate the Middlevalue
                        angleMiddleValue = angle/n;

                        //Calculate the Position of Roboter
                        position = calculatemiddlepoint(warpedCorners[i-1], warpedCorners[i], angleMiddleValue);

                        //Copy detect Marker in Circles
                        Point3f circle = Point3f(position.x, position.y, angleMiddleValue);
                        circles.push_front(circle);
                    }
                    //Otherwise, Add the Offset to get the correct Position of one Marker
                    else
                    {
                        //Calculate the Middlevalue
                        angleMiddleValue = angle/n;

                        //Calculate the Position of Roboter only with one Marker and a Offset
                        //position = calculatemiddlepoint(markerCorners[i], empty,schnittalpha);
                        position.x = 0;
                        position.y = 0;
                        Point3f circle = Point3f(position.x, position.y, angleMiddleValue);
                        circles.push_front(circle);
                    }

                    //Clear the temporary Variables for next two Markers
                    angle = 0;
                    angleMiddleValue = 0;
                }
                //If the current ID even, check the existence of the second Marker
                //If it not exist, clear the Variables for next two Marker.
                else if(markerIds.size() > i+1 && markerIds[i+1] != a+1)
                {
                    //Clear the temporary Variables for next two Markers
                    angle = 0;
                    angleMiddleValue = 0;
                }
            }
        }
    }























































































        ///for(unsigned int j = 0; j < warpedContours.size(); j++ )
///    for(unsigned int j = 0; j < warpedCorners.size(); j++ )
///    {
        ///Erzeugt das minimal kleinste Quadrat um die Punkte die gefunden wurden.
///        RotatedRect enclosingRect;
///        enclosingRect = minAreaRect(warpedContours.at(j));

///        if(liveViewMode)
///        {
///            Point2f rect_points[4];
///            enclosingRect.points( rect_points );
///            std::vector<Point2f> points;
///            for( int k = 0; k < 4; k++ )
///            {
///                points.push_back(Point2f(rect_points[k].x / GUI_SCALING, rect_points[k].y / GUI_SCALING ));
///            }

///            for( int k = 0; k < 4; k++ )
///            {
///                line( warpedImage, points[k], points[(k + 1) % 4], COLOR_YELLOW, 1, CV_AA );
///            }
///        }

///        // check if rectangle is square
///        // (a square means that contour is probably a circle)
///        double rectRatio = (double) enclosingRect.size.height / (double) enclosingRect.size.width;
///        // check if rectangle is a candidate by size
///        double diameter = sqrt(enclosingRect.size.height * enclosingRect.size.height + enclosingRect.size.width * enclosingRect.size.width );

///        if (rectRatio > 0.7 && rectRatio < 1.3 &&
///                diameter > 5 && diameter < 150)
///        {
///            if(liveViewMode)
///            {
///                Point2f rect_points[4];
///                enclosingRect.points( rect_points );
///                std::vector<Point2f> points;
///                for( int k = 0; k < 4; k++ )
///                {
///                    points.push_back(Point2f(rect_points[k].x / GUI_SCALING, rect_points[k].y / GUI_SCALING ));
///                }

///                for( int k = 0; k < 4; k++ )
///                {
///                    line( warpedImage, points[k], points[(k + 1) % 4], COLOR_MAGENTA, 1, CV_AA);
///                }
///            }

///            validContours.push_back(warpedContours[j]);
///        }

///    }

  ///  circles.clear();
 ///for( unsigned int j = 0; j < validContours.size(); j++ )
///    for(unsigned int j = 0; j < validContours.size(); j++ )
///    {
///        qDebug() << "Forschleife3";
///        Point2f center;
///        float radius;
///        minEnclosingCircle(validContours.at(j), center, radius);

///        Point3f circle = Point3f(center.x, center.y, radius);
///        if (radius > 5.0 && radius < 70.0)
///        {
///            circles.append(circle);

///            if(liveViewMode) // DRAW CIRCLE
///            {
///                center.x /= GUI_SCALING;
///                center.y /= GUI_SCALING;
///                radius /= GUI_SCALING;

///                cv::circle( warpedImage, center, radius, COLOR_GREEN, 1, CV_AA);
///                cv::circle( warpedImage, center, 70 / GUI_SCALING, COLOR_CYAN, 1, CV_AA);
///            }
///        }
///    }

///    // clean up
    /* Not necessary with STL vectors, since scope is lost on return from this function
    contours.clear();
    warpedContours.clear();
    validContours.clear();
    */
    ///hierarchy.clear();
}

void ImgTask::setImage(cv::Mat image)
{
    this->image = image;
}

void ImgTask::setCameraMatrix(cv::Mat cameraMatrix)
{
    this->cameraMatrix = cameraMatrix;
}

void ImgTask::setDistCoeffs(cv::Mat distCoeffs)
{
    this->distCoeffs = distCoeffs;
}

void ImgTask::setPerspTransfMatrix(cv::Mat perspTransfMatrix)
{
    this->perspTransfMatrix = perspTransfMatrix;

    // calculate GUI Transformation Matrix by scaling down perspTransfMatrix
    Mat scaleMatrix = Mat::zeros(3, 3, CV_64F);
    scaleMatrix.at<double>(0, 0) = 1.0 / GUI_SCALING;
    scaleMatrix.at<double>(1, 1) = 1.0 / GUI_SCALING;
    scaleMatrix.at<double>(2, 2) = 1.0;
    guiTransfMatrix = scaleMatrix * perspTransfMatrix;
}

void ImgTask::setThresh(int thresh)
{
    if(thresh <= 0)
    {
        this->thresh = 0;
    }
    else if (thresh > 255)
    {
        this->thresh = 255;
    }
    else
    {
        this->thresh = thresh;
    }
}

void ImgTask::setDebugMode(bool debugMode)
{
    this->liveViewMode = debugMode;
}

QList<cv::Point3f> ImgTask::getCircles()
{
    return circles;
}

Mat ImgTask::getWarpedImage()
{
    return warpedImage;
}
